﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Employee_PayrollSystem
{
    public class Intern:BaseEmployee
    {
        public Intern(int empid, string empname, decimal basicPay, decimal allowances, decimal deductions)
        : base(empid, empname, "Intern", basicPay, allowances, deductions)
        {
        }
    }
}
