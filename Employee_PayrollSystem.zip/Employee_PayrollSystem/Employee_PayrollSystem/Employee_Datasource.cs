﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;


namespace Employee_PayrollSystem
{
    public class Employee_Datasource
    {
        private Db_Connection db;

        public Employee_Datasource()
        {
            db = new Db_Connection();
        }
        public void SaveEmployeeToDatabase(BaseEmployee employee)
        {
            using (SqlConnection connection = db.Connect())
            {
                

                string query = "INSERT INTO Employees (Emp_id, Emp_Name, Role, BasicPay, Allowances, Deduction) VALUES (@Emp_id, @Emp_Name, @Role, @BasicPay, @Allowances, @Deduction)";

                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@Emp_id", employee.Emp_id);
                    command.Parameters.AddWithValue("@Emp_Name", employee.Emp_Name);
                    command.Parameters.AddWithValue("@Role", employee.Role);
                    command.Parameters.AddWithValue("@BasicPay", employee.BasicPay);
                    command.Parameters.AddWithValue("@Allowances", employee.Allowances);
                    command.Parameters.AddWithValue("@Deduction", employee.Deductions);

                    command.ExecuteNonQuery();
                }
            }

            Console.WriteLine("Employee data added successfully.");
        }

        public List<BaseEmployee> DisplayEmployeesFromDatabase()
        {
            List<BaseEmployee> employees = new List<BaseEmployee>();

            using (SqlConnection connection = db.Connect())
            {
                

                string query = "SELECT * FROM Employees";

                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            int emp_id = reader.GetInt32(0);
                            string emp_name = reader.GetString(1);
                            string role = reader.GetString(2);
                            decimal basicPay = reader.GetDecimal(3);
                            decimal allowances = reader.GetDecimal(4);
                            decimal deductions = reader.GetDecimal(5);

                            BaseEmployee employee = null;

                            switch (role.ToLower())
                            {
                                case "manager":
                                    employee = new Manager(emp_id, emp_name, basicPay, allowances, deductions);
                                    break;
                                case "developer":
                                    employee = new Developer(emp_id, emp_name, basicPay, allowances, deductions);
                                    break;
                                case "intern":
                                    employee = new Intern(emp_id, emp_name, basicPay, allowances, deductions);
                                    break;
                            }

                            if (employee != null)
                            {
                                employees.Add(employee);
                            }
                        }
                    }
                }
            }

            return employees;
        }

        public BaseEmployee LoadEmployeeById(int id)
        {
            BaseEmployee employee = null;

            using (SqlConnection connection = db.Connect())
            {
              

                string query = "SELECT * FROM Employees WHERE emp_id = @emp_id";

                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@emp_id", id);

                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            string name = reader.GetString(1);
                            string role = reader.GetString(2);
                            decimal basicPay = reader.GetDecimal(3);
                            decimal allowances = reader.GetDecimal(4);
                            decimal deductions = reader.GetDecimal(5);

                            switch (role.ToLower())
                            {
                                case "manager":
                                    employee = new Manager(id, name, basicPay, allowances, deductions);
                                    break;
                                case "developer":
                                    employee = new Developer(id, name, basicPay, allowances, deductions);
                                    break;
                                case "intern":
                                    employee = new Intern(id, name, basicPay, allowances, deductions);
                                    break;
                            }
                        }
                    }
                }
            }

            return employee;
        }

        public decimal CalculateTotalPayroll()
        {
            decimal totalPayroll = 0;

            using (SqlConnection connection = db.Connect())
            {
              

                string query = "SELECT BasicPay, Allowances, Deduction FROM Employees";

                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            decimal basicPay = reader.GetDecimal(0);
                            decimal allowances = reader.GetDecimal(1);
                            decimal deductions = reader.GetDecimal(2);
                            totalPayroll += (basicPay + allowances - deductions);
                        }
                    }
                }
            }

            return totalPayroll;
        }
    }
}
