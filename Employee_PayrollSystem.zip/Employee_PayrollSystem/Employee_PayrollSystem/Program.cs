﻿using Employee_PayrollSystem;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.Common;
using System.Data.SqlClient;

public class Program
{
    static List<BaseEmployee> employees = new List<BaseEmployee>();
    static Employee_Datasource employeeDatasource = new Employee_Datasource();
    static void Main(string[] args)
    {
        bool exit = false;

        while (!exit)
        {
            Console.Clear();
            Console.WriteLine("Employee Payroll System");
            Console.WriteLine("1. Add New Employee");
            Console.WriteLine("2. Display All Employees");
            Console.WriteLine("3. Calculate and Display Salary");
            Console.WriteLine("4. Calculate and Display Total Payroll");
            Console.WriteLine("5. Exit");
            Console.Write("Select an option: ");

            switch (Console.ReadLine())
            {
                case "1":
                    AddNewEmployee();
                    break;
                case "2":
                    DisplayAllEmployees();
                    break;
                case "3":
                    CalculateAndDisplaySalary();
                    break;
                case "4":
                    CalculateAndDisplayTotalPayroll();
                    break;
                case "5":
                    exit = true;
                    break;
                default:
                    Console.WriteLine("Invalid option. Please try again.");
                    break;
            }

            if (!exit)
            {
                Console.WriteLine("Press any key to continue...");
                Console.ReadKey();
            }
        }
    }
    static void AddNewEmployee()
    {
        Console.Clear();
        Console.WriteLine("Add New Employee");
        Console.Write("Name: ");
        string name = Console.ReadLine();
        Console.Write("ID: ");
        int id = int.Parse(Console.ReadLine());
        Console.Write("Role (Manager/Developer/Intern): ");
        string role = Console.ReadLine();
        Console.Write("Basic Pay: ");
        decimal basicPay = decimal.Parse(Console.ReadLine());
        Console.Write("Allowances: ");
        decimal allowances = decimal.Parse(Console.ReadLine());
        Console.Write("Deductions: ");
        decimal deductions = decimal.Parse(Console.ReadLine());

        BaseEmployee employee = null;

        switch (role.ToLower())
        {
            case "manager":
                employee = new Manager(id, name, basicPay, allowances, deductions);
                break;
            case "developer":
                employee = new Developer(id, name, basicPay, allowances, deductions);
                break;
            case "intern":
                employee = new Intern(id, name, basicPay, allowances, deductions);
                break;
            default:
                Console.WriteLine("Invalid role. Employee not added.");
                return;
        }

        employeeDatasource.SaveEmployeeToDatabase(employee);
    }

    static void DisplayAllEmployees()
    {
        Console.Clear();
        Console.WriteLine("Employee Details:");

        var employees = employeeDatasource.DisplayEmployeesFromDatabase();

        foreach (var employee in employees)
        {
            Console.WriteLine($"Name: {employee.Emp_Name}, ID: {employee.Emp_id}, Role: {employee.Role}, Salary: {employee.CalculateSalary()}");
        }
    }

    static void CalculateAndDisplaySalary()
    {
        Console.Clear();
        Console.Write("Enter Employee ID: ");
        int id = int.Parse(Console.ReadLine());

        var employee = employeeDatasource.LoadEmployeeById(id);

        if (employee != null)
        {
            Console.WriteLine($"Salary for {employee.Emp_Name} ({employee.Role}): {employee.CalculateSalary()}");
        }
        else
        {
            Console.WriteLine("Employee not found.");
        }
    }

    static void CalculateAndDisplayTotalPayroll()
    {
        Console.Clear();
        decimal totalPayroll = employeeDatasource.CalculateTotalPayroll();
        Console.WriteLine($"Total Payroll: {totalPayroll}");
    }
}
