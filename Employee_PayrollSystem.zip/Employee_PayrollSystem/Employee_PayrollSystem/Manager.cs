﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Employee_PayrollSystem
{
    public class Manager : BaseEmployee
    {
        public Manager(int empid, string empname, decimal basicPay, decimal allowances, decimal deductions)
        : base(empid, empname, "Manager", basicPay, allowances, deductions)
        {

        }
    }
}
