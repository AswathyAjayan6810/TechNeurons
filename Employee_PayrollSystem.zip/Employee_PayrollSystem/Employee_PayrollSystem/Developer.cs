﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Employee_PayrollSystem
{
    public class Developer:BaseEmployee
    {
        public Developer(int empid, string empname, decimal basicPay, decimal allowances, decimal deductions)
        : base(empid, empname, "Developer", basicPay, allowances, deductions)
        {
        }
    }
}
