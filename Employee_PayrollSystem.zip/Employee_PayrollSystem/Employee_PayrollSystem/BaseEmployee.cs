﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace Employee_PayrollSystem
{
    public class BaseEmployee
    {
        public int Emp_id { get; set; }
        public string Emp_Name { get; set; }
        public string Role { get; set; }
        public decimal BasicPay { get; set; }
        public decimal Allowances { get; set; }
        public decimal Deductions { get; set; }
        public BaseEmployee(int empid, string empname, string role, decimal basicPay, decimal allowances, decimal deductions)
        {
            Emp_id = empid;
            Emp_Name = empname;
            Role = role;
            BasicPay = basicPay;
            Allowances = allowances;
            Deductions = deductions;
        }

        public virtual decimal CalculateSalary()
        {
            return BasicPay + Allowances - Deductions;
        }
    }
}
